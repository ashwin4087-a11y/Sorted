import { CitizenCase } from '../types';
import { runHealthCheck } from '../engine/healthCheckEngine';
import { diagnoseDBTFailure } from '../engine/diagnoser';
import { compileActions } from '../engine/actionCompiler';

// 1. Golden Demo: Lakshmi (62, Tamil speaker, PM-KISAN DBT payment failure)
const lakshmiDocs = [
  {
    id: 'DOC-LAKSHMI-AADHAAR',
    docType: 'AADHAAR' as const,
    name: 'Aadhaar Card (Lakshmi K)',
    number: '381249568912',
    holderName: 'Lakshmi K',
    dob: '1964-06-12',
    address: '14, South Street, Thiruvaiyaru, Thanjavur, Tamil Nadu 613204',
    issueDate: '2016-04-10',
    verified: true
  },
  {
    id: 'DOC-LAKSHMI-PASSBOOK',
    docType: 'BANK_PASSBOOK' as const,
    name: 'Canara Bank Passbook',
    accountNumber: '1204101089234',
    bankName: 'Canara Bank (Thiruvaiyaru Branch)',
    ifsc: 'CNRB0001204',
    holderName: 'K. Lakshmi',
    seedingReported: 'NOT_OK' as const,
    verified: true
  },
  {
    id: 'DOC-LAKSHMI-ACK',
    docType: 'APPLICATION_ACK' as const,
    name: 'PM-KISAN Sanction Slip',
    number: 'TN-PMK-2026-99042',
    verified: true
  },
  {
    id: 'DOC-LAKSHMI-STATUS',
    docType: 'PFMS_STATUS' as const,
    name: 'PFMS Payment Status Screenshot',
    rawText: 'Payment Mode: Aadhaar | Status: Rejected by Bank | Reason Code: P-U1 (Aadhaar de-seeded in NPCI mapper)',
    verified: true
  }
];

const lakshmiDiagnosis = diagnoseDBTFailure({
  applicationApproved: true,
  paymentGenerated: true,
  paymentFailed: true,
  reportedReasonText: 'Payment Mode: Aadhaar | Reason Code: P-U1 (Aadhaar de-seeded in NPCI mapper)',
  hasDocumentProof: true,
  sourceDocName: 'PFMS Status Screenshot'
});

const lakshmiHealth = runHealthCheck('PM-KISAN', lakshmiDocs);
const lakshmiActions = compileActions(lakshmiDiagnosis, lakshmiHealth.ruleTraces);

export const LAKSHMI_CASE: CitizenCase = {
  id: 'CASE_LAKSHMI',
  caseRef: 'CASE-004821',
  createdDate: '14 OCT 2026',
  schemeName: 'PM-KISAN Samman Nidhi',
  citizenName: 'Lakshmi K',
  citizenAge: 62,
  language: 'ta',
  location: 'Thanjavur, Tamil Nadu',
  journey: 'POST_SUBMISSION_DBT_FAILURE',
  status: 'ACTION_READY',
  readinessPercentage: 42,
  documents: lakshmiDocs,
  extractedFacts: [
    {
      id: 'F-1',
      key: 'citizen_identity',
      label: 'Citizen Identity',
      value: 'Lakshmi K (Age 62)',
      provenance: 'VERIFIED',
      sourceDoc: 'Aadhaar Card',
      confidence: 'HIGH'
    },
    {
      id: 'F-2',
      key: 'scheme_status',
      label: 'Scheme Sanction',
      value: 'Approved (Sanction TN-PMK-2026-99042)',
      provenance: 'VERIFIED',
      sourceDoc: 'PM-KISAN Sanction Slip',
      confidence: 'HIGH'
    },
    {
      id: 'F-3',
      key: 'disbursement_failure',
      label: 'Disbursement Status',
      value: 'Returned / Rejected by Bank',
      provenance: 'VERIFIED',
      sourceDoc: 'PFMS Status Screenshot',
      confidence: 'HIGH'
    },
    {
      id: 'F-4',
      key: 'pfms_error_code',
      label: 'PFMS Failure Code',
      value: 'P-U1 (Aadhaar de-seeded)',
      provenance: 'VERIFIED',
      sourceDoc: 'PFMS Status Screenshot',
      confidence: 'HIGH'
    },
    {
      id: 'F-5',
      key: 'bank_npci_mapping',
      label: 'NPCI DBT Mapping',
      value: 'INACTIVE / DE-SEEDED in Canara Bank',
      provenance: 'USER_REPORTED',
      sourceDoc: 'Citizen Statement',
      confidence: 'MEDIUM'
    }
  ],
  ruleTraces: lakshmiHealth.ruleTraces,
  diagnosis: lakshmiDiagnosis,
  actions: lakshmiActions,
  events: [
    {
      id: 'EV-1',
      timestamp: '14 OCT 2026 · 10:14',
      eventType: 'CASE_CREATED',
      title: 'Case Registered on SORTED Terminal',
      description: 'Lakshmi reported non-receipt of two consecutive PM-KISAN instalments.',
      actor: 'CITIZEN'
    },
    {
      id: 'EV-2',
      timestamp: '14 OCT 2026 · 10:16',
      eventType: 'DOCUMENT_UPLOADED',
      title: 'Aadhaar and Bank Passbook Processed',
      description: 'Extracted Aadhaar 3812-XXXX-8912 and Canara Bank A/C 1204XXXX89234.',
      actor: 'SORTED_AI'
    },
    {
      id: 'EV-3',
      timestamp: '14 OCT 2026 · 10:18',
      eventType: 'DIAGNOSIS_PERFORMED',
      title: 'PFMS Diagnostic Code P-U1 Confirmed',
      description: 'Deterministic match against PFMS DBT error taxonomy: Aadhaar de-seeded.',
      actor: 'PFMS_ENGINE'
    },
    {
      id: 'EV-4',
      timestamp: '14 OCT 2026 · 10:19',
      eventType: 'LETTER_GENERATED',
      title: 'Official Bank Mandate Letter Generated',
      description: 'Prepared dual-language (Tamil / English) Aadhaar seeding requisition with Annexure I.',
      actor: 'SORTED_AI'
    }
  ]
};

// 2. Pre-Submission Prevention Demo: Kavitha (DAYALU / Annapurna Scheme with DOB Year Mismatch)
const kavithaDocs = [
  {
    id: 'DOC-KAVITHA-AADHAAR',
    docType: 'AADHAAR' as const,
    name: 'Aadhaar Card (Kavitha Devi)',
    number: '542198031254',
    holderName: 'Kavitha Devi',
    dob: '1964-03-21',
    address: 'House 82, Ward 4, Ambala Cantt, Haryana 133001',
    verified: true
  },
  {
    id: 'DOC-KAVITHA-FAMILY-ID',
    docType: 'DEATH_CERTIFICATE' as const,
    name: 'Parivar Pehchan Patra / Municipal Record',
    holderName: 'Kavitha Devi',
    dob: '1962-03-21',
    verified: true
  },
  {
    id: 'DOC-KAVITHA-PASSBOOK',
    docType: 'BANK_PASSBOOK' as const,
    name: 'State Bank of India Passbook',
    accountNumber: '30491823901',
    bankName: 'State Bank of India',
    ifsc: 'SBIN0000600',
    holderName: 'Kavitha Devi',
    seedingReported: 'OK' as const,
    verified: true
  }
];

const kavithaHealth = runHealthCheck('Mukhyamantri DAYALU Scheme', kavithaDocs);
const kavithaActions = compileActions(undefined, kavithaHealth.ruleTraces);

export const KAVITHA_CASE: CitizenCase = {
  id: 'CASE_KAVITHA',
  caseRef: 'CASE-007194',
  createdDate: '14 OCT 2026',
  schemeName: 'Mukhyamantri DAYALU Scheme',
  citizenName: 'Kavitha Devi',
  citizenAge: 60,
  language: 'en',
  location: 'Ambala, Haryana',
  journey: 'PRE_SUBMISSION_HEALTH_CHECK',
  status: 'CITIZEN_ACTION_REQUIRED',
  readinessPercentage: 65,
  documents: kavithaDocs,
  extractedFacts: [
    {
      id: 'FK-1',
      key: 'name_identity',
      label: 'Applicant Name',
      value: 'Kavitha Devi',
      provenance: 'VERIFIED',
      sourceDoc: 'Aadhaar & Passbook',
      confidence: 'HIGH'
    },
    {
      id: 'FK-2',
      key: 'aadhaar_dob',
      label: 'Aadhaar Birth Date',
      value: '21/03/1964 (Year: 1964)',
      provenance: 'VERIFIED',
      sourceDoc: 'Aadhaar Card',
      confidence: 'HIGH'
    },
    {
      id: 'FK-3',
      key: 'family_dob',
      label: 'Family Record Birth Date',
      value: '21/03/1962 (Year: 1962)',
      provenance: 'VERIFIED',
      sourceDoc: 'Municipal Pehchan Patra',
      confidence: 'HIGH'
    },
    {
      id: 'FK-4',
      key: 'bank_seeding',
      label: 'NPCI Seeding',
      value: 'Linked in SBI',
      provenance: 'USER_REPORTED',
      sourceDoc: 'Citizen Statement',
      confidence: 'MEDIUM'
    }
  ],
  ruleTraces: kavithaHealth.ruleTraces,
  actions: kavithaActions,
  events: [
    {
      id: 'EVK-1',
      timestamp: '14 OCT 2026 · 11:02',
      eventType: 'CASE_CREATED',
      title: 'Pre-Submission Verification Initiated',
      description: 'Applicant uploaded Aadhaar, SBI Passbook, and Municipal Pehchan Patra.',
      actor: 'CITIZEN'
    },
    {
      id: 'EVK-2',
      timestamp: '14 OCT 2026 · 11:03',
      eventType: 'HEALTH_CHECK_COMPLETED',
      title: 'Pre-submission Health Check Flagged Discrepancy',
      description: 'DOB Year Mismatch (1964 vs 1962) detected. High risk of clerical rejection before submission.',
      actor: 'SORTED_AI'
    }
  ]
};
