import React from 'react';
import { CitizenCase } from '../types';
import { RubberStamp } from './RubberStamp';
import { MapPin, Clock, CheckSquare, AlertCircle, FileCheck, Printer } from 'lucide-react';

interface OneTripPlannerViewProps {
  currentCase: CitizenCase;
}

export const OneTripPlannerView: React.FC<OneTripPlannerViewProps> = ({
  currentCase
}) => {
  const bankDoc = currentCase.documents.find(d => d.docType === 'BANK_PASSBOOK');

  const trips = [
    {
      id: 'TRIP-1',
      tripNumber: 1,
      destinationName: bankDoc?.bankName || 'Home Bank Branch',
      destinationType: 'BANK',
      operatingHours: '10:00 AM – 02:00 PM (Monday to Friday, avoid 2nd/4th Saturday)',
      purpose: 'Aadhaar Seeding & NPCI DBT Beneficiary Mapper Activation',
      counterToApproach: 'Customer Service / Accounts Service Desk (or Branch Manager)',
      whatToCarry: [
        'Original Aadhaar Card (mandatory for biometric or visual match)',
        '2 Self-attested photocopies of Aadhaar Card',
        'Original Bank Passbook (A/C: ' + (bankDoc?.accountNumber || '1204XXXX89234') + ')',
        '2 Passport-sized photographs',
        'SORTED Generated Bank Request Letter (signed by you)'
      ],
      exactStatementToStaff:
        '"Sir/Madam, I am an approved beneficiary under ' +
        currentCase.schemeName +
        '. My PFMS payments are failing under code ' +
        (currentCase.diagnosis?.code || 'P-U1') +
        ' because my Aadhaar is not active on the NPCI mapper. Please link my Aadhaar in CBS and tick the mandate for NPCI DBT credit."',
      nonNegotiableExitCriteria:
        'DO NOT LEAVE WITHOUT: A stamped acknowledgement slip with a CBS Service Request (SR) or Ticket Number certifying NPCI mapping registration.',
      turnaroundTime: '48 to 72 hours for CBS update, 5–7 days for NPCI mapper sync.'
    },
    {
      id: 'TRIP-2',
      tripNumber: 2,
      destinationName: 'Block Development Office (BDO) / Taluk Supply Office',
      destinationType: 'DEPARTMENT',
      operatingHours: '11:00 AM – 04:00 PM (Working days)',
      purpose: 'Verify Portal Status & Re-trigger Payment Lot (if bank seeding completed)',
      counterToApproach: 'Scheme Nodal Officer Desk / DBT Grievance Cell',
      whatToCarry: [
        'Bank Stamped Acknowledgement Slip (obtained from Trip 1)',
        'Original Aadhaar Card & Ration Card',
        'Scheme Application Acknowledgement Slip (' + currentCase.caseRef + ')'
      ],
      exactStatementToStaff:
        '"My bank has updated the NPCI mapper. Kindly inspect my beneficiary record in the scheme portal and confirm my status is cleared for the upcoming Fund Transfer Order (FTO)."',
      nonNegotiableExitCriteria:
        'DO NOT LEAVE WITHOUT: Written or printed confirmation that your record status shows "Bank Validated" or "Ready for Next Disbursement Lot".',
      turnaroundTime: 'Next scheduled state disbursement cycle.'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white border border-[#123B63] shadow-hard p-5 rounded-[2px] flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-mono-tech text-[10px] text-[#123B63] font-bold tracking-widest uppercase">
              EFFICIENCY ENGINE // ONE-TRIP LOGISTICS
            </span>
            <span className="text-[10px] font-mono-tech text-[#5B6B80]">
              DEPENDENCY GRAPH COMPILED
            </span>
          </div>
          <h2 className="font-display font-[800] text-2xl text-[#0C2A47] tracking-tight mt-1">
            Citizen One-Trip Logistics Planner
          </h2>
          <p className="text-sm text-[#5B6B80] mt-0.5">
            Actions topologically sorted by physical destination so the citizen makes the minimum visits without repeated trips.
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="btn-instrument bg-[#123B63] text-white px-4 py-2 text-xs flex items-center gap-2"
        >
          <Printer className="w-4 h-4" />
          <span>PRINT TRIP CHECKLIST</span>
        </button>
      </div>

      {/* Trips Timeline */}
      <div className="space-y-5">
        {trips.map((trip) => (
          <div
            key={trip.id}
            className="bg-white border-2 border-[#123B63] shadow-hard p-5 rounded-[2px] space-y-4"
          >
            {/* Trip Destination Title Bar */}
            <div className="flex flex-wrap items-center justify-between border-b border-[#DCE5ED] pb-3 gap-2">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-[2px] bg-[#123B63] text-white font-mono-tech font-[800] text-sm flex items-center justify-center">
                  #{trip.tripNumber}
                </div>
                <div>
                  <span className="font-mono-tech text-[10px] text-[#5B6B80] uppercase tracking-wider block">
                    DESTINATION {trip.tripNumber} // {trip.destinationType}
                  </span>
                  <h3 className="font-display font-[800] text-lg text-[#0C2A47]">
                    {trip.destinationName}
                  </h3>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <RubberStamp
                  variant={trip.tripNumber === 1 ? 'ACTION_REQUIRED' : 'PENDING'}
                  label={trip.tripNumber === 1 ? 'STEP 1: VISIT FIRST' : 'STEP 2: POST-SEEDING'}
                  size="sm"
                />
              </div>
            </div>

            {/* Logistics Metadata */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 bg-[#F7FAFC] p-3 border border-[#DCE5ED] text-xs font-mono-tech">
              <div className="flex items-center gap-2 text-[#17212B]">
                <Clock className="w-4 h-4 text-[#123B63] shrink-0" />
                <span>HOURS: <strong>{trip.operatingHours}</strong></span>
              </div>
              <div className="flex items-center gap-2 text-[#17212B]">
                <MapPin className="w-4 h-4 text-[#123B63] shrink-0" />
                <span>COUNTER: <strong>{trip.counterToApproach}</strong></span>
              </div>
            </div>

            {/* Checklist of what to carry */}
            <div className="space-y-2">
              <span className="font-mono-tech text-[11px] font-bold text-[#123B63] uppercase block">
                WHAT TO CARRY IN YOUR BAG (DO NOT LEAVE HOME WITHOUT THESE):
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {trip.whatToCarry.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-2 bg-[#F7FAFC] border border-[#DCE5ED] p-2 rounded-[2px] text-xs text-[#17212B]"
                  >
                    <CheckSquare className="w-4 h-4 text-[#2E7D57] shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Exact words to say */}
            <div className="bg-[#FEF7EA] border border-[#F4B942] p-3 rounded-[2px] space-y-1">
              <span className="font-display font-[800] text-xs text-[#D99020] uppercase block">
                EXACT STATEMENT TO TELL THE OFFICER / TELLER:
              </span>
              <p className="text-xs text-[#17212B] italic leading-relaxed">
                {trip.exactStatementToStaff}
              </p>
            </div>

            {/* Mandatory Exit Criteria */}
            <div className="bg-[#EBF7F0] border border-[#56A67A] p-3 rounded-[2px] flex items-start gap-2 text-xs">
              <AlertCircle className="w-4 h-4 text-[#2E7D57] shrink-0 mt-0.5" />
              <div>
                <strong className="text-[#2E7D57] font-display uppercase block">
                  NON-NEGOTIABLE EXIT PROOF:
                </strong>
                <p className="text-[#17212B] mt-0.5">
                  {trip.nonNegotiableExitCriteria}
                </p>
              </div>
            </div>

            <div className="text-[11px] font-mono-tech text-[#5B6B80] pt-1">
              EXPECTED SYSTEM SYNC TIME: {trip.turnaroundTime}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
