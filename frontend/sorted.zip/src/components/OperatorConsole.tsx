import React, { useState } from 'react';
import { CitizenCase, ExtractedFact, ProvenanceType } from '../types';
import { RubberStamp } from './RubberStamp';
import { Send, HelpCircle, CheckCircle2, AlertTriangle, ArrowRight, Sparkles } from 'lucide-react';

interface OperatorConsoleProps {
  currentCase: CitizenCase;
  onUpdateCase: (updatedCase: CitizenCase) => void;
  onTriggerDiagnosis: (errorText: string) => void;
}

export const OperatorConsole: React.FC<OperatorConsoleProps> = ({
  currentCase,
  onUpdateCase,
  onTriggerDiagnosis
}) => {
  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState<'en' | 'ta'>(currentCase.language);
  const [showWhyExplain, setShowWhyExplain] = useState(false);

  // Suggested quick prompts representing real citizen questions/complaints
  const quickPrompts = selectedLanguage === 'ta' ? [
    { label: 'ரூபாய் வரவில்லை (P-U1 ஆதார் பிழை)', text: 'எனது பிஎம் கிசான் விண்ணப்பம் ஏற்கப்பட்டது, ஆனால் 2 தவணை பணம் வரவில்லை. ஆதார் NPCI மேப்பரில் இல்லை (P-U1) என்று வருகிறது.' },
    { label: 'காரணம் தெரியவில்லை (UNKNOWN)', text: 'பணம் வரவில்லை என்று எஸ்.எம்.எஸ் வந்தது, ஆனால் எந்த பிழை குறியீடும் காட்டவில்லை. என்ன செய்வது?' },
    { label: 'வங்கிக் கணக்கு மூடப்பட்டது (P-A7)', text: 'பணம் செலுத்தப்பட்டது ஆனால் வங்கி நிராகரித்தது (Rejected by bank, account closed).' }
  ] : [
    { label: 'Payment Failed: Aadhaar de-seeded (P-U1)', text: 'My PM-KISAN application was approved, but the last 2 instalments failed with error: Aadhaar de-seeded in NPCI mapper (P-U1).' },
    { label: 'Payment Failed: Unknown PFMS Reason', text: 'My pension was approved 3 months ago, but no money has been credited and I do not have any rejection code.' },
    { label: 'Bank Validation: Invalid IFSC (V-A2)', text: 'Portal says DBT payment rejected due to invalid IFSC after branch merger.' }
  ];

  const handleSend = async (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim()) return;

    setIsProcessing(true);

    try {
      // Call server backend /api/operator or execute local deterministic pipeline
      let serverResponse: any = null;
      try {
        const res = await fetch('/api/operator', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: text,
            language: selectedLanguage,
            caseId: currentCase.id,
            existingFacts: currentCase.extractedFacts
          })
        });
        if (res.ok) {
          serverResponse = await res.json();
        }
      } catch (err) {
        // Fall back to client deterministic handling
      }

      // If server returned structured extraction, update facts
      if (serverResponse && serverResponse.extractedFact) {
        const newFact: ExtractedFact = serverResponse.extractedFact;
        const updatedFacts = [...currentCase.extractedFacts.filter(f => f.key !== newFact.key), newFact];
        
        onUpdateCase({
          ...currentCase,
          extractedFacts: updatedFacts,
          events: [
            ...currentCase.events,
            {
              id: `EV-OP-${Date.now()}`,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              eventType: 'FACT_EXTRACTED',
              title: `Fact Extracted: ${newFact.label}`,
              description: `Citizen provided: "${newFact.value}" (${newFact.provenance})`,
              actor: 'SORTED_AI'
            }
          ]
        });
      }

      // Trigger DBT diagnosis if failure keywords are found
      onTriggerDiagnosis(text);
      setInputText('');
    } finally {
      setIsProcessing(false);
    }
  };

  const provenanceBadge = (prov: ProvenanceType) => {
    switch (prov) {
      case 'VERIFIED':
        return <RubberStamp variant="VERIFIED" size="sm" />;
      case 'USER_REPORTED':
        return <RubberStamp variant="USER_CONFIRMED" label="USER REPORTED" size="sm" />;
      case 'INFERRED':
        return <RubberStamp variant="PENDING" label="INFERRED" size="sm" />;
      case 'UNKNOWN':
      default:
        return <RubberStamp variant="BLOCKED" label="UNKNOWN" size="sm" />;
    }
  };

  return (
    <div className="bg-white border border-[#123B63] shadow-hard rounded-[2px] overflow-hidden flex flex-col font-body-gov">
      {/* Console Top Instrument Bar */}
      <div className="bg-[#0C2A47] text-[#E2EAF2] px-4 py-3 flex flex-wrap items-center justify-between border-b-2 border-[#123B63] gap-2">
        <div className="flex items-center gap-3">
          <div className="w-2.5 h-2.5 bg-[#56A67A] rounded-[1px] animate-pulse" />
          <span className="font-mono-tech text-xs font-bold tracking-widest uppercase">
            OPERATOR CONSOLE // CITIZEN INTAKE & TRIAGE
          </span>
        </div>

        {/* Language switch */}
        <div className="flex items-center gap-1 bg-[#081D33] p-1 border border-[#061526] rounded-[2px]">
          <button
            onClick={() => {
              setSelectedLanguage('en');
              onUpdateCase({ ...currentCase, language: 'en' });
            }}
            className={`px-2 py-0.5 text-xs font-mono-tech font-bold transition-all rounded-[1px] ${
              selectedLanguage === 'en'
                ? 'bg-[#123B63] text-white'
                : 'text-[#5B6B80] hover:text-white'
            }`}
          >
            ENGLISH
          </button>
          <button
            onClick={() => {
              setSelectedLanguage('ta');
              onUpdateCase({ ...currentCase, language: 'ta' });
            }}
            className={`px-2 py-0.5 text-xs font-mono-tech font-bold transition-all rounded-[1px] ${
              selectedLanguage === 'ta'
                ? 'bg-[#123B63] text-white'
                : 'text-[#5B6B80] hover:text-white'
            }`}
          >
            தமிழ் (TAMIL)
          </button>
        </div>
      </div>

      {/* Main Console Quadrants per Section 28 Directive */}
      <div className="p-4 space-y-5">
        
        {/* 1. CITIZEN INPUT SECTION */}
        <div>
          <div className="flex items-center justify-between border-b border-[#DCE5ED] pb-1.5 mb-2.5">
            <span className="font-display font-[800] text-xs text-[#0C2A47] tracking-wider uppercase">
              1. CITIZEN INPUT & STATEMENT
            </span>
            <span className="font-mono-tech text-[10px] text-[#5B6B80]">
              CASE: {currentCase.caseRef}
            </span>
          </div>

          <div className="flex flex-col gap-2">
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={
                selectedLanguage === 'ta'
                  ? 'உங்கள் பிரச்சனை அல்லது வங்கி/PFMS எஸ்.எம்.எஸ் செய்தியை உள்ளிடவும்...'
                  : 'Describe your government benefit issue, or paste your PFMS / Bank SMS status...'
              }
              rows={3}
              className="w-full p-3 text-sm bg-[#F7FAFC] border border-[#123B63] rounded-[2px] font-body-gov focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#123B63]"
            />

            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="font-mono-tech text-[10px] text-[#5B6B80] uppercase">
                  SIMULATE INTAKE:
                </span>
                {quickPrompts.map((p, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setInputText(p.text);
                      handleSend(p.text);
                    }}
                    className="text-[11px] font-mono-tech bg-[#F7FAFC] hover:bg-[#EBF7F0] hover:text-[#2E7D57] text-[#123B63] border border-[#DCE5ED] px-2 py-0.5 rounded-[2px] transition-colors"
                  >
                    {p.label}
                  </button>
                ))}
              </div>

              <button
                onClick={() => handleSend()}
                disabled={isProcessing || !inputText.trim()}
                className="btn-instrument bg-[#123B63] text-white px-4 py-1.5 text-xs flex items-center gap-1.5 disabled:opacity-50"
              >
                {isProcessing ? (
                  <span>CALIBRATING...</span>
                ) : (
                  <>
                    <span>SUBMIT INPUT</span>
                    <Send className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* 2. SORTED ANALYSIS SECTION */}
        <div className="bg-[#F7FAFC] border border-[#DCE5ED] p-3.5 rounded-[2px]">
          <div className="flex items-center justify-between border-b border-[#DCE5ED] pb-1.5 mb-2">
            <span className="font-display font-[800] text-xs text-[#0C2A47] tracking-wider uppercase">
              2. SORTED SYSTEM ANALYSIS
            </span>
            <span className="font-mono-tech text-[10px] text-[#56A67A] font-bold">
              TAXONOMY ENGINE: DETERMINISTIC
            </span>
          </div>

          <p className="text-sm text-[#17212B] leading-relaxed">
            {selectedLanguage === 'ta' ? (
              <>
                <strong>நிலைப்பாடு:</strong> விண்ணப்பதாரர் <strong>{currentCase.citizenName}</strong> ({currentCase.schemeName}) அவர்களின் 
                கட்டணம் நிறுத்தி வைக்கப்பட்டுள்ளதற்கான காரணம் கண்டறியப்பட்டது. 
                இது வங்கி அளவில் ஆதார் NPCI மேப்பர் செயலிழப்பு (P-U1) காரணமாக PFMS வழியே திரும்பி அனுப்பப்பட்டுள்ளது. 
                இது அரசாங்க தகுதிக் குறைபாடு அல்ல; சரிசெய்யக்கூடிய வங்கி மேப்பர் சிக்கல்.
              </>
            ) : (
              <>
                <strong>Diagnosis Summary:</strong> Applicant <strong>{currentCase.citizenName}</strong> for scheme <strong>{currentCase.schemeName}</strong> has encountered a documented payment return. 
                The transaction failed under PFMS Code <strong>{currentCase.diagnosis?.code || 'P-U1'}</strong> ({currentCase.diagnosis?.title || 'Aadhaar de-seeded'}). 
                This is a clerical bank-switch mapping status, not a rejection of statutory scheme eligibility.
              </>
            )}
          </p>
        </div>

        {/* 3. EXTRACTED FACTS (WITH PROVENANCE TAGS) */}
        <div>
          <div className="flex items-center justify-between border-b border-[#DCE5ED] pb-1.5 mb-2.5">
            <span className="font-display font-[800] text-xs text-[#0C2A47] tracking-wider uppercase">
              3. EXTRACTED FACTS & PROVENANCE LEDGER
            </span>
            <span className="font-mono-tech text-[10px] text-[#5B6B80]">
              TOTAL FACTS: {currentCase.extractedFacts.length}
            </span>
          </div>

          <div className="border border-[#DCE5ED] divide-y divide-[#DCE5ED] bg-white rounded-[2px] overflow-hidden">
            {currentCase.extractedFacts.map((fact) => (
              <div
                key={fact.id}
                className="p-2.5 flex flex-wrap items-center justify-between gap-2 hover:bg-[#F7FAFC] transition-colors"
              >
                <div className="flex flex-col">
                  <div className="flex items-center gap-2">
                    <span className="font-mono-tech text-[11px] font-semibold text-[#123B63]">
                      {fact.label}
                    </span>
                    {fact.sourceDoc && (
                      <span className="text-[10px] font-mono-tech text-[#5B6B80]">
                        [DOC: {fact.sourceDoc}]
                      </span>
                    )}
                  </div>
                  <span className="font-display font-bold text-sm text-[#0C2A47]">
                    {fact.value}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="font-mono-tech text-[10px] text-[#5B6B80]">
                    CONFIDENCE: {fact.confidence}
                  </span>
                  {provenanceBadge(fact.provenance)}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 4. NEXT REQUIRED INPUT & ACTION GUIDANCE */}
        <div className="bg-[#FEF7EA] border border-[#F4B942] p-3.5 rounded-[2px]">
          <div className="flex items-center justify-between border-b border-[#F4B942]/60 pb-1.5 mb-2">
            <div className="flex items-center gap-2">
              <span className="font-display font-[800] text-xs text-[#D99020] tracking-wider uppercase">
                4. NEXT REQUIRED ACTION & INPUT
              </span>
            </div>
            <button
              onClick={() => setShowWhyExplain(!showWhyExplain)}
              className="text-[10px] font-mono-tech text-[#123B63] underline flex items-center gap-1 hover:text-[#0C2A47]"
            >
              <HelpCircle className="w-3 h-3" />
              <span>Why am I being asked this?</span>
            </button>
          </div>

          {showWhyExplain && (
            <div className="mb-2 p-2 bg-white border border-[#DCE5ED] text-xs text-[#5B6B80] leading-normal rounded-[2px]">
              <strong>Administrative Rule:</strong> Under Ministry of Finance and NPCI circulars, a bank account can be KYC-compliant but deactivated for DBT receipt if the customer has not signed an explicit Annexure I mandate mapping Aadhaar to the bank's IIN. Taking this letter ensures the bank official updates CBS rather than turning you away.
            </div>
          )}

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="font-display font-bold text-sm text-[#0C2A47] flex items-center gap-1.5">
                <ArrowRight className="w-4 h-4 text-[#D99020]" />
                <span>
                  {selectedLanguage === 'ta'
                    ? 'வங்கிக்குச் சென்று ஆதார் இணைப்பு (Aadhaar Seeding) ஒப்புதல் படிவத்தை சமர்ப்பிக்கவும்'
                    : 'Submit Aadhaar Seeding Consent & NPCI Mandate Form at Canara Bank'}
                </span>
              </div>
              <p className="text-xs text-[#5B6B80]">
                {selectedLanguage === 'ta'
                  ? 'தயாரிக்கப்பட்ட வங்கி கோரிக்கை மனுவினை அச்சிட்டு அசல் ஆதாருடன் எடுத்துச் செல்லவும்.'
                  : 'Print the generated official bank letter and carry original Aadhaar + Passbook.'}
              </p>
            </div>

            <div className="shrink-0">
              <RubberStamp variant="ACTION_REQUIRED" size="md" />
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
