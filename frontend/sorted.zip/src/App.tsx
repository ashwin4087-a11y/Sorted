import React, { useState } from 'react';
import { CitizenCase } from './types';
import { LAKSHMI_CASE, KAVITHA_CASE } from './data/demoCases';
import { SortedLogo } from './components/SortedLogo';
import { RubberStamp } from './components/RubberStamp';
import { MechanicalOdometer } from './components/MechanicalOdometer';
import { OperatorConsole } from './components/OperatorConsole';
import { PreSubmissionHealthCheck } from './components/PreSubmissionHealthCheck';
import { DBTFailureDiagnoser } from './components/DBTFailureDiagnoser';
import { GeneratedArtifactsView } from './components/GeneratedArtifactsView';
import { OneTripPlannerView } from './components/OneTripPlannerView';
import { CaseTimelineTracker } from './components/CaseTimelineTracker';
import { diagnoseDBTFailure } from './engine/diagnoser';
import { compileActions } from './engine/actionCompiler';
import { runHealthCheck } from './engine/healthCheckEngine';
import { 
  Activity, 
  FileCheck2, 
  Stethoscope, 
  FileText, 
  MapPin, 
  GitBranch, 
  UserCheck, 
  RotateCcw,
  Sparkles
} from 'lucide-react';

type ActiveTab = 
  | 'CONSOLE' 
  | 'HEALTH_CHECK' 
  | 'DBT_DIAGNOSER' 
  | 'LETTERS' 
  | 'ONE_TRIP' 
  | 'TIMELINE';

export default function App() {
  const [activeCaseId, setActiveCaseId] = useState<'LAKSHMI' | 'KAVITHA'>('LAKSHMI');
  const [currentCase, setCurrentCase] = useState<CitizenCase>(LAKSHMI_CASE);
  const [activeTab, setActiveTab] = useState<ActiveTab>('CONSOLE');

  const switchCase = (caseId: 'LAKSHMI' | 'KAVITHA') => {
    setActiveCaseId(caseId);
    if (caseId === 'LAKSHMI') {
      setCurrentCase(LAKSHMI_CASE);
      setActiveTab('DBT_DIAGNOSER');
    } else {
      setCurrentCase(KAVITHA_CASE);
      setActiveTab('HEALTH_CHECK');
    }
  };

  const handleTriggerDiagnosis = (errorText: string) => {
    const diag = diagnoseDBTFailure({
      applicationApproved: true,
      paymentGenerated: true,
      paymentFailed: true,
      reportedReasonText: errorText,
      hasDocumentProof: true,
      sourceDocName: 'Operator Console / Citizen Triage'
    });

    const health = runHealthCheck(currentCase.schemeName, currentCase.documents);
    const newActions = compileActions(diag, health.ruleTraces);

    const updatedCase: CitizenCase = {
      ...currentCase,
      diagnosis: diag,
      status: diag.isUnknownReason ? 'NEEDS_INFO' : 'ACTION_READY',
      readinessPercentage: diag.isUnknownReason ? 30 : 42,
      actions: newActions,
      events: [
        ...currentCase.events,
        {
          id: `EV-DIAG-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          eventType: 'DIAGNOSIS_PERFORMED',
          title: `Diagnostic Evaluation: ${diag.code}`,
          description: `Identified: ${diag.title} (${diag.confidence} confidence)`,
          actor: 'PFMS_ENGINE'
        }
      ]
    };

    setCurrentCase(updatedCase);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F7FAFC] text-[#17212B]">
      
      {/* 1. TOP BAR CONTRACT: Exhaustive 3-zone architecture */}
      <header className="bg-white border-b border-[#DCE5ED] sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
          
          {/* Zone 1: Single element Brand Zone */}
          <div className="shrink-0 flex items-center">
            <SortedLogo size="md" />
          </div>

          {/* Zone 2: Clean 4–6 text navigation links */}
          <nav className="hidden md:flex items-center gap-1 text-xs font-mono-tech overflow-x-auto py-1">
            <button
              onClick={() => setActiveTab('CONSOLE')}
              className={`px-3 py-1.5 font-bold uppercase transition-colors whitespace-nowrap rounded-[2px] ${
                activeTab === 'CONSOLE'
                  ? 'bg-[#123B63] text-white shadow-sm'
                  : 'text-[#5B6B80] hover:text-[#0C2A47]'
              }`}
            >
              Operator Console
            </button>
            <button
              onClick={() => setActiveTab('HEALTH_CHECK')}
              className={`px-3 py-1.5 font-bold uppercase transition-colors whitespace-nowrap rounded-[2px] ${
                activeTab === 'HEALTH_CHECK'
                  ? 'bg-[#123B63] text-white shadow-sm'
                  : 'text-[#5B6B80] hover:text-[#0C2A47]'
              }`}
            >
              Pre-Submission Check
            </button>
            <button
              onClick={() => setActiveTab('DBT_DIAGNOSER')}
              className={`px-3 py-1.5 font-bold uppercase transition-colors whitespace-nowrap rounded-[2px] ${
                activeTab === 'DBT_DIAGNOSER'
                  ? 'bg-[#123B63] text-white shadow-sm'
                  : 'text-[#5B6B80] hover:text-[#0C2A47]'
              }`}
            >
              DBT Failure Diagnoser
            </button>
            <button
              onClick={() => setActiveTab('LETTERS')}
              className={`px-3 py-1.5 font-bold uppercase transition-colors whitespace-nowrap rounded-[2px] ${
                activeTab === 'LETTERS'
                  ? 'bg-[#123B63] text-white shadow-sm'
                  : 'text-[#5B6B80] hover:text-[#0C2A47]'
              }`}
            >
              Generated Letters
            </button>
            <button
              onClick={() => setActiveTab('ONE_TRIP')}
              className={`px-3 py-1.5 font-bold uppercase transition-colors whitespace-nowrap rounded-[2px] ${
                activeTab === 'ONE_TRIP'
                  ? 'bg-[#123B63] text-white shadow-sm'
                  : 'text-[#5B6B80] hover:text-[#0C2A47]'
              }`}
            >
              One-Trip Planner
            </button>
            <button
              onClick={() => setActiveTab('TIMELINE')}
              className={`px-3 py-1.5 font-bold uppercase transition-colors whitespace-nowrap rounded-[2px] ${
                activeTab === 'TIMELINE'
                  ? 'bg-[#123B63] text-white shadow-sm'
                  : 'text-[#5B6B80] hover:text-[#0C2A47]'
              }`}
            >
              Case Timeline
            </button>
          </nav>

          {/* Zone 3: 1-2 primary actions */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="flex items-center gap-1 bg-[#F7FAFC] border border-[#123B63] p-0.5 rounded-[2px]">
              <button
                onClick={() => switchCase('LAKSHMI')}
                className={`px-2.5 py-1 text-xs font-mono-tech font-bold transition-all rounded-[1px] whitespace-nowrap ${
                  activeCaseId === 'LAKSHMI'
                    ? 'bg-[#123B63] text-white shadow-sm'
                    : 'text-[#5B6B80] hover:text-[#0C2A47]'
                }`}
              >
                Lakshmi (DBT Blocker)
              </button>
              <button
                onClick={() => switchCase('KAVITHA')}
                className={`px-2.5 py-1 text-xs font-mono-tech font-bold transition-all rounded-[1px] whitespace-nowrap ${
                  activeCaseId === 'KAVITHA'
                    ? 'bg-[#123B63] text-white shadow-sm'
                    : 'text-[#5B6B80] hover:text-[#0C2A47]'
                }`}
              >
                Kavitha (Pre-Submission)
              </button>
            </div>
          </div>
        </div>

        {/* Signature Header Stripe */}
        <div className="signature-stripe" />
      </header>

      {/* Mobile Nav Bar */}
      <div className="md:hidden bg-white border-b border-[#DCE5ED] px-4 py-2 flex items-center gap-1 overflow-x-auto text-[11px] font-mono-tech font-bold">
        <button
          onClick={() => setActiveTab('CONSOLE')}
          className={`px-2 py-1 rounded-[2px] whitespace-nowrap ${activeTab === 'CONSOLE' ? 'bg-[#123B63] text-white' : 'text-[#5B6B80]'}`}
        >
          Console
        </button>
        <button
          onClick={() => setActiveTab('HEALTH_CHECK')}
          className={`px-2 py-1 rounded-[2px] whitespace-nowrap ${activeTab === 'HEALTH_CHECK' ? 'bg-[#123B63] text-white' : 'text-[#5B6B80]'}`}
        >
          Health Check
        </button>
        <button
          onClick={() => setActiveTab('DBT_DIAGNOSER')}
          className={`px-2 py-1 rounded-[2px] whitespace-nowrap ${activeTab === 'DBT_DIAGNOSER' ? 'bg-[#123B63] text-white' : 'text-[#5B6B80]'}`}
        >
          Diagnoser
        </button>
        <button
          onClick={() => setActiveTab('LETTERS')}
          className={`px-2 py-1 rounded-[2px] whitespace-nowrap ${activeTab === 'LETTERS' ? 'bg-[#123B63] text-white' : 'text-[#5B6B80]'}`}
        >
          Letters
        </button>
        <button
          onClick={() => setActiveTab('ONE_TRIP')}
          className={`px-2 py-1 rounded-[2px] whitespace-nowrap ${activeTab === 'ONE_TRIP' ? 'bg-[#123B63] text-white' : 'text-[#5B6B80]'}`}
        >
          One-Trip
        </button>
        <button
          onClick={() => setActiveTab('TIMELINE')}
          className={`px-2 py-1 rounded-[2px] whitespace-nowrap ${activeTab === 'TIMELINE' ? 'bg-[#123B63] text-white' : 'text-[#5B6B80]'}`}
        >
          Timeline
        </button>
      </div>

      {/* 2. CASE SUB-HEADER METADATA STRIP */}
      <div className="bg-[#0C2A47] text-[#E2EAF2] border-b border-[#061526] px-4 sm:px-6 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs font-mono-tech">
          <div className="flex flex-wrap items-center gap-3">
            <span className="font-bold text-[#F4B942] tracking-wider">
              ACTIVE CASE: {currentCase.caseRef}
            </span>
            <span aria-hidden="true" className="text-[#5B6B80]">·</span>
            <span>CITIZEN: <strong className="text-white">{currentCase.citizenName}</strong> ({currentCase.citizenAge} YRS)</span>
            <span aria-hidden="true" className="text-[#5B6B80]">·</span>
            <span>SCHEME: <strong className="text-white">{currentCase.schemeName}</strong></span>
            <span aria-hidden="true" className="text-[#5B6B80]">·</span>
            <span className="text-[#5B6B80]">{currentCase.location}</span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[#5B6B80]">
              STATE: <strong className="text-[#56A67A]">{currentCase.status}</strong>
            </span>
            <RubberStamp variant="DEMO_DATA" size="sm" />
          </div>
        </div>
      </div>

      {/* 3. MAIN APPLICATION WORKSPACE */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 w-full flex-1">
        {activeTab === 'CONSOLE' && (
          <div className="space-y-6">
            <OperatorConsole
              currentCase={currentCase}
              onUpdateCase={setCurrentCase}
              onTriggerDiagnosis={handleTriggerDiagnosis}
            />
          </div>
        )}

        {activeTab === 'HEALTH_CHECK' && (
          <PreSubmissionHealthCheck
            currentCase={currentCase}
            onUpdateCase={setCurrentCase}
          />
        )}

        {activeTab === 'DBT_DIAGNOSER' && (
          <DBTFailureDiagnoser
            currentCase={currentCase}
            onUpdateCase={setCurrentCase}
            onTriggerDiagnosis={handleTriggerDiagnosis}
            onSelectLetterTab={() => setActiveTab('LETTERS')}
          />
        )}

        {activeTab === 'LETTERS' && (
          <GeneratedArtifactsView
            currentCase={currentCase}
          />
        )}

        {activeTab === 'ONE_TRIP' && (
          <OneTripPlannerView
            currentCase={currentCase}
          />
        )}

        {activeTab === 'TIMELINE' && (
          <CaseTimelineTracker
            currentCase={currentCase}
            onUpdateCase={setCurrentCase}
          />
        )}
      </main>

      {/* 4. FOOTER: Technical administrative provenance note */}
      <footer className="bg-white border-t border-[#DCE5ED] mt-auto py-4 px-4 sm:px-6 text-xs text-[#5B6B80] font-mono-tech">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <SortedLogo size="sm" />
            <span>— Government Benefit Resolution Platform</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span>PFMS Failure Table v1.0</span>
            <span aria-hidden="true">·</span>
            <span>UIDAI Verhoeff Polynomial Engine</span>
            <span aria-hidden="true">·</span>
            <span>Deterministic Rule Execution</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
