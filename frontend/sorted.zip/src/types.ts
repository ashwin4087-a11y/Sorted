/**
 * SORTED — Types & Data Structures
 * Strictly typed government-benefit resolution model
 */

export type ProvenanceType = 'VERIFIED' | 'USER_REPORTED' | 'INFERRED' | 'UNKNOWN';

export type ConfidenceLevel = 'HIGH' | 'MEDIUM' | 'LOW';

export type CaseStatus = 
  | 'NEW'
  | 'UNDERSTANDING'
  | 'DIAGNOSED'
  | 'ACTION_READY'
  | 'CITIZEN_ACTION_REQUIRED'
  | 'SUBMITTED'
  | 'WAITING'
  | 'FOLLOW_UP_REQUIRED'
  | 'ESCALATED'
  | 'RESOLVED'
  | 'NEEDS_INFO';

export type HealthCheckOverallStatus = 'READY' | 'WARNING' | 'BLOCKED' | 'UNKNOWN';

export type NameMatchResult = 'MATCH' | 'MINOR_VARIATION' | 'POSSIBLE_MISMATCH' | 'MISMATCH' | 'UNKNOWN';
export type DobMatchResult = 'MATCH' | 'MISMATCH' | 'YEAR_MISMATCH_ONLY' | 'MISSING' | 'UNKNOWN';
export type AddressMatchResult = 'CONSISTENT' | 'POSSIBLE_VARIATION' | 'MISMATCH' | 'UNKNOWN';
export type ExpiryResult = 'VALID' | 'EXPIRING_SOON' | 'EXPIRED' | 'UNKNOWN';
export type RequiredDocResult = 'PRESENT' | 'MISSING' | 'UNCLEAR';
export type AadhaarFormatResult = 'VALID' | 'INVALID' | 'UNCHECKED';
export type AadhaarSeedingResult = 'USER_REPORTED_OK' | 'USER_REPORTED_NOT_OK' | 'UNKNOWN';

export interface ExtractedFact {
  id: string;
  key: string;
  label: string;
  value: string;
  provenance: ProvenanceType;
  sourceDoc?: string;
  confidence: ConfidenceLevel;
  notes?: string;
}

export interface PFMSTaxonomyEntry {
  id: string;
  stage: 'Validation, account' | 'Validation, Aadhaar' | 'Payment, account' | 'Payment, Aadhaar';
  reason: string;
  remedy: string;
  responsible: 'Citizen' | 'Department' | 'Bank' | 'Department (citizen supplies)';
  destination: 'Bank' | 'Department' | 'Bank + Department';
  sourceName: string;
  sourceUrl: string;
  retrievedAt: string;
  version: number;
}

export interface RuleTraceItem {
  id: string;
  ruleName: string;
  category: 'IDENTITY' | 'AGE' | 'RESIDENCE' | 'VALIDITY' | 'BANK_SEEDING' | 'COMPLIANCE';
  resultStatus: 'PASS' | 'WARNING' | 'FAIL' | 'UNKNOWN';
  resultCode: string;
  summary: string;
  detail: string;
  evidence: string;
  testedDocuments: string[];
  remedyRequired?: string;
}

export interface DiagnosisResult {
  code: string;
  title: string;
  stage: string;
  remedy: string;
  responsible: string;
  destination: string;
  confidence: ConfidenceLevel;
  evidence: string;
  evidenceSource: string;
  taxonomySource: string;
  isUnknownReason: boolean;
  nextAction: string;
}

export interface ActionItem {
  id: string;
  title: string;
  destination: 'BANK' | 'DEPARTMENT' | 'CSC' | 'CITIZEN_HOME';
  destinationLabel: string;
  responsibleParty: string;
  severity: 'BLOCKING' | 'WARNING' | 'INFORMATIONAL';
  instructions: string[];
  whatToCarry: string[];
  expectedOutput: string;
  requiresLetter: boolean;
  letterType?: 'BANK_REQUEST' | 'DEPARTMENT_CORRECTION' | 'DEPARTMENT_REASON_REQUEST' | 'KYC_UPDATE' | 'ESCALATION';
}

export interface CaseDocument {
  id: string;
  docType: 'AADHAAR' | 'BANK_PASSBOOK' | 'DEATH_CERTIFICATE' | 'RATION_CARD' | 'APPLICATION_ACK' | 'SMS_SCREENSHOT' | 'PFMS_STATUS';
  name: string;
  number?: string;
  holderName?: string;
  dob?: string;
  address?: string;
  issueDate?: string;
  expiryDate?: string;
  bankName?: string;
  ifsc?: string;
  accountNumber?: string;
  seedingReported?: 'OK' | 'NOT_OK' | 'UNKNOWN';
  rawText?: string;
  verified: boolean;
}

export interface CaseEvent {
  id: string;
  timestamp: string;
  eventType: 
    | 'CASE_CREATED'
    | 'FACT_EXTRACTED'
    | 'DOCUMENT_UPLOADED'
    | 'DIAGNOSIS_PERFORMED'
    | 'HEALTH_CHECK_COMPLETED'
    | 'LETTER_GENERATED'
    | 'CITIZEN_ACTION_MARKED'
    | 'SIMULATED_DAY_3_REMINDER'
    | 'SIMULATED_DAY_7_CHECK'
    | 'STATUS_UPDATED'
    | 'RESOLVED';
  title: string;
  description: string;
  actor: 'CITIZEN' | 'SORTED_AI' | 'PFMS_ENGINE' | 'BANK' | 'DEPARTMENT';
}

export interface CitizenCase {
  id: string;
  caseRef: string; // e.g. CASE-004821
  createdDate: string;
  schemeName: string;
  citizenName: string;
  citizenAge: number;
  language: 'en' | 'ta';
  location: string;
  journey: 'PRE_SUBMISSION_HEALTH_CHECK' | 'POST_SUBMISSION_DBT_FAILURE';
  status: CaseStatus;
  readinessPercentage: number;
  documents: CaseDocument[];
  extractedFacts: ExtractedFact[];
  ruleTraces: RuleTraceItem[];
  diagnosis?: DiagnosisResult;
  actions: ActionItem[];
  events: CaseEvent[];
}
