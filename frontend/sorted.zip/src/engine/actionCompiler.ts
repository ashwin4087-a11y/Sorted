import { ActionItem, DiagnosisResult, RuleTraceItem } from '../types';

export function compileActions(
  diagnosis?: DiagnosisResult,
  ruleTraces: RuleTraceItem[] = []
): ActionItem[] {
  const actions: ActionItem[] = [];

  // Compile from DBT failure diagnosis
  if (diagnosis) {
    if (diagnosis.destination.includes('Bank')) {
      const isSeeding = diagnosis.code.includes('U1') || diagnosis.code.includes('U2') || diagnosis.code.includes('U3') || diagnosis.code.includes('U4') || diagnosis.code.includes('U5');
      actions.push({
        id: 'ACT-BANK-01',
        title: isSeeding ? 'Submit Aadhaar Seeding & NPCI DBT Mandate at Bank' : 'Complete Bank KYC & Account Verification',
        destination: 'BANK',
        destinationLabel: 'Home Bank Branch (Customer Service Desk)',
        responsibleParty: 'Citizen',
        severity: 'BLOCKING',
        instructions: [
          'Visit your home branch between 10:00 AM and 2:00 PM.',
          'Request the official "Aadhaar Seeding & NPCI DBT Enablement Form" (Annexure I).',
          'Tick the consent checkbox specifically authorizing DBT benefit credits via NPCI mapper.',
          'Mandatory: Do NOT leave without a stamped acknowledgement slip from the bank official.'
        ],
        whatToCarry: [
          'Original Aadhaar Card + 2 self-attested photocopies',
          'Original Bank Passbook',
          'Government Scheme Registration / Acknowledgement Slip',
          'Two passport-sized photographs'
        ],
        expectedOutput: 'Stamped Bank Acknowledgement Slip with CBS Reference Number confirming NPCI mapper update.',
        requiresLetter: true,
        letterType: 'BANK_REQUEST'
      });
    }

    if (diagnosis.destination.includes('Department')) {
      const isUnknown = diagnosis.isUnknownReason;
      actions.push({
        id: 'ACT-DEPT-01',
        title: isUnknown 
          ? 'Request PFMS Payment Rejection Code from Scheme Nodal Officer' 
          : 'Submit Rectified Records to Block / Scheme Department Office',
        destination: 'DEPARTMENT',
        destinationLabel: 'Block Development Office (BDO) / Taluk Supply Officer',
        responsibleParty: 'Citizen',
        severity: 'BLOCKING',
        instructions: [
          'Visit the Block Development Office or Taluk Office Scheme Helpdesk.',
          isUnknown 
            ? 'Present the generated letter requesting the exact PFMS payment rejection sub-code.'
            : 'Submit the updated bank passbook and identity documents to update the beneficiary portal.',
          'Request the nodal clerk to pull up your record on the scheme portal and verify the status.'
        ],
        whatToCarry: [
          'Generated Official Request Letter',
          'Original Aadhaar Card',
          'Application Acknowledgement with registration number',
          'Bank passbook showing recent transactions'
        ],
        expectedOutput: isUnknown 
          ? 'Written PFMS failure code and sub-reason slip.'
          : 'Online portal status updated to "Ready for FTO".',
        requiresLetter: true,
        letterType: isUnknown ? 'DEPARTMENT_REASON_REQUEST' : 'DEPARTMENT_CORRECTION'
      });
    }
  }

  // Compile from Health Check rule traces
  for (const trace of ruleTraces) {
    if (trace.resultStatus === 'FAIL') {
      if (trace.ruleName === 'DOB_MATCH') {
        actions.push({
          id: 'ACT-CORRECT-DOB',
          title: 'Obtain Age / Date of Birth Clerical Correction Certificate',
          destination: 'DEPARTMENT',
          destinationLabel: 'Municipal Corporation / Gram Panchayat Office',
          responsibleParty: 'Citizen',
          severity: 'BLOCKING',
          instructions: [
            'Visit the issuing municipal / panchayat authority with primary family records.',
            'Request a certified clerical correction memo reconciling the birth year.',
            'Keep both documents along with the rectification memo before submitting the scheme application.'
          ],
          whatToCarry: [
            'Primary Family ID / Ration Card',
            'Certificate with divergent date',
            'Affidavit on stamp paper or Panchayat Secretary recommendation letter'
          ],
          expectedOutput: 'Official endorsement memo reconciling birth year.',
          requiresLetter: false
        });
      }

      if (trace.ruleName === 'NAME_MATCH') {
        actions.push({
          id: 'ACT-NAME-RECTIFY',
          title: 'Align Name Spelling Between Bank Account and Aadhaar',
          destination: 'BANK',
          destinationLabel: 'Home Bank Branch',
          responsibleParty: 'Citizen',
          severity: 'BLOCKING',
          instructions: [
            'Request the bank teller to update your customer information file (CIF) name exactly matching Aadhaar.',
            'Ensure the passbook is reprinted with the correct spelling.'
          ],
          whatToCarry: [
            'Original Aadhaar Card',
            'Existing Bank Passbook',
            'KYC Form with exact Aadhaar spelling'
          ],
          expectedOutput: 'Reprinted Passbook front page with matching name.',
          requiresLetter: false
        });
      }
    }
  }

  return actions;
}
