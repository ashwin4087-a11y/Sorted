import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

// Initialize Gemini client if API key is provided
let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    aiClient = new GoogleGenAI();
  } catch (err) {
    console.warn('Gemini client initialization warning:', err);
  }
}

// 1. Operator Intake & Fact Extraction API
app.post('/api/operator', async (req: Request, res: Response) => {
  const { message, language = 'en', existingFacts = [] } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Message is required' });
  }

  // If Gemini API is available, use it for structured reasoning
  if (aiClient && process.env.GEMINI_API_KEY) {
    try {
      const prompt = `You are the AI triage operator for SORTED, an administrative government-benefit resolution platform in India.
Citizen statement: "${message}"
Language: ${language}
Existing facts: ${JSON.stringify(existingFacts)}

Extract any key facts from the citizen statement. Respond ONLY in valid JSON matching this schema:
{
  "extractedFact": {
    "id": "F_extracted_${Date.now()}",
    "key": "reported_issue",
    "label": "Reported Benefit Blocker",
    "value": "string summarizing statement in plain words",
    "provenance": "USER_REPORTED",
    "confidence": "MEDIUM"
  },
  "explanation": "Brief explanation in ${language === 'ta' ? 'Tamil' : 'English'}",
  "suggestedFailureCode": "e.g. P-U1, V-A2, or UNKNOWN"
}`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json'
        }
      });

      const parsed = JSON.parse(response.text || '{}');
      return res.json(parsed);
    } catch (err) {
      console.warn('Gemini API call fell back to deterministic engine:', err);
    }
  }

  // Deterministic fallback if API key is not active
  let detectedCode = 'UNKNOWN';
  let label = 'Reported Benefit Blocker';
  const lower = message.toLowerCase();

  if (lower.includes('p-u1') || lower.includes('deseed') || lower.includes('de-seed') || (lower.includes('aadhaar') && lower.includes('seed'))) {
    detectedCode = 'P-U1';
    label = 'Aadhaar NPCI Mapping Blocker';
  } else if (lower.includes('ifsc')) {
    detectedCode = 'V-A2';
    label = 'Invalid IFSC Branch Error';
  } else if (lower.includes('kyc') || lower.includes('pending 6 months')) {
    detectedCode = 'V-A6';
    label = 'Pending KYC Validation Error';
  } else if (lower.includes('closed')) {
    detectedCode = 'P-A7';
    label = 'Account Closed by Bank';
  }

  return res.json({
    extractedFact: {
      id: `F_extracted_${Date.now()}`,
      key: 'citizen_reported_statement',
      label,
      value: message.slice(0, 100),
      provenance: 'USER_REPORTED',
      confidence: 'MEDIUM'
    },
    suggestedFailureCode: detectedCode,
    explanation: language === 'ta'
      ? 'விண்ணப்பதாரர் அளித்த தகவல் அமைப்பில் பதிவு செய்யப்பட்டது.'
      : 'Citizen statement recorded in case ledger.'
  });
});

// 2. Health check route
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    system: 'SORTED Administrative Instrument Engine',
    geminiActive: Boolean(process.env.GEMINI_API_KEY)
  });
});

// Vite middleware in dev or static files in production
async function setupVite() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, () => {
    console.log(`SORTED Platform running on http://localhost:${port}`);
  });
}

setupVite();
